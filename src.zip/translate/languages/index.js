import { StringsComuns as englishMessages } from './en'

const StringsComuns = {
    ...englishMessages
}

export { StringsComuns }
