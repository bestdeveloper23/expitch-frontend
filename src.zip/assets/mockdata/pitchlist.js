// mockData.js

const pitchlist = [
    {
      id: 1,
      name: 'Electronics',
      scroe: 'C+',
      date: "2023-12-04T15:30:00Z"
    },
    {
      id: 2,
      name: 'Clothing',
      score: 'A',
      date: "2023-12-03T15:30:00Z"
    },
    {
      id: 3,
      name: 'Trading',
      score: 'A',
      date: "2023-12-03T15:30:00Z"
    },
    {
      id: 4,
      name: 'Investing',
      score: 'A',
      date: "2023-12-03T15:30:00Z"
    },
    {
      id: 5,
      name: 'Hotel booking',
      score: 'A',
      date: "2023-12-03T15:30:00Z"
    }
    // Add more category objects as needed
  ];
  
  export default pitchlist;
  