export const SET_EMAIL = "SET_EMAIL";
export const SET_FILE = "SET_FILE";
export const SET_USER = "SET_USER";