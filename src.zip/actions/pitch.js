import {
    SET_EMAIL,
    SET_FILE
} from "./types";

export const setEmail = (email) => ({
 type: SET_EMAIL,
 payload: email,
});

export const setFile = (file) => ({
 type: SET_FILE,
 payload: file,
});